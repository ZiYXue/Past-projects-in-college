This is a video game for all ages��������

This game is what I finished when I was a freshman. There are some minor bugs but is not disturbing you enjoy in it.

Keyboard operation keys: is the four direction keys.Among them left, right, the next three key meaning is the same, the function of the key is not to make the square up, but to make the square Angle changes.
