// Tetris1App.cpp: implementation of the Tetris1App class.
//
//////////////////////////////////////////////////////////////////////

#include "Tetris1.h"
#include "tetris1.h"
#include "Tetris1App.h"
#include "Tetris1Wnd.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
Tetris1App theapp;

BOOL Tetris1App::InitInstance()
{
	m_pMainWnd = new Tetris1Wnd;
    m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();
	return true;
}
Tetris1App::Tetris1App()
{
	
}

Tetris1App::~Tetris1App()
{

}
