// Tetris1App.h: interface for the Tetris1App class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TETRIS1APP_H__86A446F1_73A1_4D3E_84DA_C2A5156527B0__INCLUDED_)
#define AFX_TETRIS1APP_H__86A446F1_73A1_4D3E_84DA_C2A5156527B0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Tetris1App : public CWinApp  
{
public:
	Tetris1App();
	virtual ~Tetris1App();
	BOOL InitInstance();

};

#endif // !defined(AFX_TETRIS1APP_H__86A446F1_73A1_4D3E_84DA_C2A5156527B0__INCLUDED_)
