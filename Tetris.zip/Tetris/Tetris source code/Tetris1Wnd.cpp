// Tetris1Wnd.cpp : implementation file
//

//#include "stdafx.h"
#include "tetris1.h"
#include "Tetris1Wnd.h"

#include "resource.h"
#include "mmsystem.h"
#pragma comment(lib,"winmm.lib")
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Tetris1Wnd

IMPLEMENT_DYNCREATE(Tetris1Wnd, CFrameWnd)

int state = 1;

Tetris1Wnd::Tetris1Wnd()
{
	//���ڵ�����
	Create(NULL,"����˹����",WS_OVERLAPPED|WS_SYSMENU|WS_MINIMIZEBOX);
	this->SetWindowPos(NULL,0,0,500,600,0);


	//�˵���������
	CMenu menu;
	menu.LoadMenu(IDR_MENU1);
	this->SetMenu(&menu);
	

	//��ʼ���������
	bitmap.LoadBitmap(IDB_BITMAPMain);
	mdc=new CDC;
	CClientDC dc(this);//�����ͼ��������ʼ��Ϊ��ǰ�ͻ���
	mdc->CreateCompatibleDC(&dc);
	jiemian.LoadBitmap(IDB_BITMAP2);
	fangkuai.LoadBitmap(IDB_BITMAP4);

	start=false;
	m_bPause=false;

}


Tetris1Wnd::~Tetris1Wnd()
{
}


BEGIN_MESSAGE_MAP(Tetris1Wnd, CFrameWnd)
	//{{AFX_MSG_MAP(Tetris1Wnd)
	ON_WM_PAINT()
	ON_COMMAND(ID_MUSIC1, OnMusic1)
	ON_COMMAND(ID_MUSIC2, OnMusic2)
	ON_COMMAND(ID_ABOUT, OnAbout)
	ON_COMMAND(ID_Guan1, OnGuan1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Tetris1Wnd message handlers

void Tetris1Wnd::OnPaint() 
{

	CPaintDC dc(this);

	CRect Rect;
	GetClientRect(&Rect);

	CBitmap bit;
	bit.LoadBitmap(IDB_BITMAPMain);

	BITMAP bmp;
	bit.GetBitmap(&bmp);

	mdc->SelectObject(bit);
	dc.StretchBlt(0,0,Rect.Width(),Rect.Height(),mdc,0,0,bmp.bmWidth,bmp.bmHeight,SRCCOPY);

	if(state == 1)
	{
		CBitmap bit;
		bit.LoadBitmap(IDB_BITMAP2);
	}

}




void Tetris1Wnd::OnMusic1() 
{	
		mciSendString("play 1.mp3",0,0,0);	
}


void Tetris1Wnd::OnMusic2() 
{
		mciSendString("stop 1.mp3",0,0,0);
		mciSendString("play 2.mp3",0,0,0);
}

void Tetris1Wnd::OnAbout() 
{
	MessageBox("@����˹������ ����","Jion US",MB_OK+MB_ICONINFORMATION);
	
}



void Tetris1Wnd::OnGuan1() 
{
	state = 1;
	Invalidate();
	
}
