#if !defined(AFX_TETRIS1WND_H__50A9E367_DEE6_4B80_A6E0_F798C14859B7__INCLUDED_)
#define AFX_TETRIS1WND_H__50A9E367_DEE6_4B80_A6E0_F798C14859B7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Tetris1Wnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Tetris1Wnd frame

class Tetris1Wnd : public CFrameWnd
{
	DECLARE_DYNCREATE(Tetris1Wnd)
public:
	Tetris1Wnd();           // protected constructor used by dynamic creation

// Attributes
public:

	//��ʾ����
	void DrawJiemian(CDC*pDC);
    //��ʼ
	void Start();
public:

	//��Ϸ����
	int Russia[100][100]; 
	// ��ǰͼ��
	int Now[4][4]; 	
	//��һͼ��
	int Will[4][4]; 
	//�任���ͼ��
	int After[4][4];
	



	//ͼ�Σ�
	CDC *mdc;
	CBitmap bitmap;
	//����
	CBitmap fangkuai;
	//����
	CBitmap jiemian;
	CDC* pDC;

	 //��ͣ
	BOOL m_bPause;
	//��ʼ��־
	bool start; 


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Tetris1Wnd)
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~Tetris1Wnd();

	// Generated message map functions
	//{{AFX_MSG(Tetris1Wnd)
	afx_msg void OnPaint();
	afx_msg void OnMusic1();
	afx_msg void OnMusic2();
	afx_msg void OnAbout();
	afx_msg void OnDraw();
	afx_msg void OnGuan1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TETRIS1WND_H__50A9E367_DEE6_4B80_A6E0_F798C14859B7__INCLUDED_)
