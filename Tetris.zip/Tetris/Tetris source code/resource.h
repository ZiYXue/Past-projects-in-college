//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Tetris1.rc
//
#define IDB_BITMAP1                     101
#define IDB_BITMAP2                     101
#define IDD_DIALOG1                     102
#define IDR_MENU1                       103
#define IDR_ACCELERATOR1                106
#define IDB_BITMAPMain                  108
#define IDB_BITMAP4                     109
#define IDB_BITMAP3                     110
#define ID_Guan1                        40001
#define ID_Guan2                        40002
#define ID_Guan3                        40003
#define ID_Guan4                        40004
#define ID_MUSIC1                       40005
#define ID_Gong                         40006
#define ID_STOP                         40007
#define ID_EXIT                         40008
#define ID_ABOUT                        40009
#define ID_MUSIC2                       40010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40011
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
